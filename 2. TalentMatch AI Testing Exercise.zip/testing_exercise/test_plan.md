# Test Plan - TalentMatch Candidate-Ranking AI

## Objective and decision

Determine whether the fictional TalentMatch model is fit to proceed from a
limited validation environment to a controlled pilot. Testing covers data
quality, model utility, subgroup outcomes, robustness, drift, documentation, and
evidence completeness. The validation team can recommend GO, CONDITIONAL GO, or
HOLD; the accountable business owner and AI Risk Committee make the decision.

## Scope

- Synthetic population: 6,000 applicants; 4,200 training and 1,800 testing.
- Protected-group field: used only for fairness testing and excluded from model
  inputs.
- Baseline: logistic model learned from deliberately biased historical
  selections.
- Challenger: logistic model limited to structured, job-related inputs and
  trained against a synthetic job-success outcome.
- Out of scope: production security testing, privacy impact assessment, actual
  legal compliance, accessibility/accommodation testing, vendor controls, and
  external independent bias-audit status.

## Test procedures

1. Reperform SQL uniqueness, completeness, domain, split, and population
   reconciliations.
2. Re-run the seeded model pipeline and reconcile row counts, parameters,
   thresholds, and scores to retained evidence.
3. Evaluate ROC AUC, accuracy, Brier score, and selection rate against synthetic
   job-success outcomes.
4. Calculate subgroup selection rates, impact ratio, true-positive-rate gap,
   false-positive-rate gap, and positive predictive value.
5. Simulate a changed applicant channel, measure required-feature missingness,
   score population stability, and AUC change.
6. Inspect standardized coefficients and data lineage for proxy-like variables.
7. Compare the baseline with a constrained challenger; do not accept mitigation
   solely because one metric improves.
8. Confirm limitations, owners, approvals, human-review steps, notices, appeals,
   monitoring thresholds, and rollback conditions are documented before any
   pilot.

## Portfolio policy thresholds

| Domain | Metric | Gate |
|---|---|---|
| Data quality | Required-feature missingness | <= 5% |
| Performance | ROC AUC | >= 0.75 |
| Fairness screening | Impact ratio | 0.80-1.25 |
| Fairness screening | Absolute TPR/FPR gap | <= 0.10 |
| Drift | Score PSI | < 0.20 |
| Drift | Absolute AUC decline | <= 0.05 |

These thresholds are illustrative risk-appetite choices, not universal legal or
industry standards. They must be approved for the specific purpose, population,
jurisdiction, and harm context.

## Evidence requirements

- Approved use-case record and impact assessment.
- Data dictionary, lineage, quality results, consent/notice analysis, and
  retention rules.
- Versioned code, environment, random seed, features, coefficients, thresholds,
  and change history.
- Overall, subgroup, intersectional, drift, and sensitivity results with sample
  sizes and uncertainty.
- Independent validation review, issue log, remediation evidence, and retest.
- Human-review procedure, reviewer competence, override reason codes, appeal and
  accommodation process.
- Monitoring dashboard, alert thresholds, incident response, rollback, and
  retirement criteria.
