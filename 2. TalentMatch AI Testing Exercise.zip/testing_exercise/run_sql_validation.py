#!/usr/bin/env python3
"""Execute the SQL validation checks and retain evidence in CSV/JSON form."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence"
DATA = EVIDENCE / "applicants_synthetic.csv"
SQL_FILE = ROOT / "data_validation.sql"


def split_queries(sql_text: str) -> list[tuple[str, str]]:
    checks: list[tuple[str, str]] = []
    current_id = ""
    current_lines: list[str] = []
    for line in sql_text.splitlines():
        stripped = line.strip()
        if stripped.startswith("-- CHECK "):
            if current_id and current_lines:
                checks.append((current_id, "\n".join(current_lines).strip()))
            current_id = stripped.split(":", 1)[0].replace("-- CHECK ", "").strip()
            current_lines = []
        elif current_id and not stripped.startswith("--"):
            current_lines.append(line)
    if current_id and current_lines:
        checks.append((current_id, "\n".join(current_lines).strip()))
    return [(check_id, query) for check_id, query in checks if query]


def main() -> None:
    applicants = pd.read_csv(DATA)
    connection = sqlite3.connect(":memory:")
    applicants.to_sql("applicants", connection, index=False)
    checks = split_queries(SQL_FILE.read_text(encoding="utf-8"))
    summary = []
    details = []
    exception_checks = {"DQ-01", "DQ-02", "DQ-03", "DQ-04"}

    for check_id, query in checks:
        result = pd.read_sql_query(query, connection)
        if check_id in exception_checks:
            status = "PASS" if result.empty else "FAIL"
            expectation = "zero exception rows"
        else:
            status = "PASS"
            expectation = "reconciliation output retained"
        summary.append(
            {
                "check_id": check_id,
                "status": status,
                "returned_rows": len(result),
                "expectation": expectation,
            }
        )
        if not result.empty:
            result.insert(0, "check_id", check_id)
            details.append(result)

    summary_frame = pd.DataFrame(summary)
    summary_frame.to_csv(EVIDENCE / "sql_validation_summary.csv", index=False)
    if details:
        pd.concat(details, ignore_index=True, sort=False).to_csv(
            EVIDENCE / "sql_validation_details.csv", index=False
        )
    with (EVIDENCE / "sql_validation_run.json").open("w", encoding="utf-8") as handle:
        json.dump(
            {
                "database": "in-memory SQLite",
                "source_file": DATA.name,
                "query_file": SQL_FILE.name,
                "checks_executed": len(summary_frame),
                "failed_checks": int((summary_frame["status"] == "FAIL").sum()),
            },
            handle,
            indent=2,
        )
    print(summary_frame.to_string(index=False))


if __name__ == "__main__":
    main()
