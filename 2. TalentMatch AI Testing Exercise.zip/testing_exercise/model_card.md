# Model Card - TalentMatch Baseline and Challenger

## Intended use

TalentMatch is a fictional decision-support system that ranks applicants for
human review. It must not autonomously reject candidates. The intended user is a
trained recruiting reviewer operating under a documented review, override,
notice, accommodation, and appeal process.

## Prohibited and out-of-scope uses

- Fully automated hire, rejection, promotion, compensation, or termination.
- Reuse for a job family, geography, or population not covered by validation.
- Use of protected-group data as a model input.
- Use when required notices, bias-audit obligations, or human-review controls
  have not been satisfied.
- Deployment after material model, data, threshold, vendor, or intended-purpose
  change without change assessment and retesting.

## Baseline model

The baseline is an interpretable logistic model trained on intentionally flawed
historical decisions. Protected-group membership is excluded, but referral,
selective-school, and career-gap variables act as proxy-risk indicators. The
exercise therefore demonstrates why "fairness through unawareness" is
insufficient.

The baseline failed the portfolio gates for ROC AUC, impact ratio,
true-positive-rate gap, false-positive-rate gap, and drift-sample missingness.
Its disposition is HOLD.

## Challenger model

The challenger uses technical-test score, structured-interview score, relevant
experience, and relevant degree. It improves the impact ratio from 0.534 to
0.841 and the true-positive-rate gap from 0.244 to 0.089 in this synthetic run.
This does not establish that the challenger is fair, lawful, or production
ready. It still requires job-analysis evidence, legal and HR review,
intersectional testing, accommodations analysis, threshold sensitivity,
independent validation, and controlled monitoring.

## Known limitations

- All data and outcomes are synthetic and simplify real hiring dynamics.
- The protected-group field uses abstract groups rather than real demographic
  categories.
- The model omits intersectional groups, disability, age, small-sample
  uncertainty, language/accessibility effects, and temporal feedback loops.
- The "qualified" label is an engineered proxy for future success, not a real
  validated criterion.
- The exercise tests a simple classifier, not a vendor product, resume parser,
  foundation model, or multimodal interviewing tool.
- No privacy, cybersecurity, adversarial, explainability-user, or accessibility
  test is complete.

## Monitoring and change triggers

Monitor input completeness, feature distributions, scores, selections,
subgroup outcomes, overrides, complaints, accommodations, appeals, model
performance, and incidents. Trigger review on a threshold breach, new
jurisdiction, material vendor/model version, new data source, changed purpose,
model retraining, unexplained override pattern, or evidence of harm.
