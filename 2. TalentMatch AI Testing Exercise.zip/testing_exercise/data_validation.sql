-- TalentMatch synthetic AI testing exercise
-- SQL data-quality checks executed against the generated applicants table.
-- Each query should return zero rows unless the query is explicitly a reconciliation.

-- CHECK DQ-01: Duplicate applicant identifiers (expected: zero rows).
SELECT applicant_id, COUNT(*) AS duplicate_count
FROM applicants
GROUP BY applicant_id
HAVING COUNT(*) > 1;

-- CHECK DQ-02: Missing required model inputs (expected: zero rows).
SELECT applicant_id
FROM applicants
WHERE technical_test IS NULL
   OR structured_interview IS NULL
   OR relevant_experience_years IS NULL
   OR relevant_degree IS NULL
   OR network_referral IS NULL
   OR selective_school IS NULL
   OR career_gap IS NULL;

-- CHECK DQ-03: Values outside defined domains (expected: zero rows).
SELECT applicant_id
FROM applicants
WHERE technical_test NOT BETWEEN 25 AND 100
   OR structured_interview NOT BETWEEN 25 AND 100
   OR relevant_experience_years NOT BETWEEN 0 AND 14
   OR relevant_degree NOT IN (0, 1)
   OR network_referral NOT IN (0, 1)
   OR selective_school NOT IN (0, 1)
   OR career_gap NOT IN (0, 1)
   OR historical_selected NOT IN (0, 1)
   OR qualified_ground_truth NOT IN (0, 1);

-- CHECK DQ-04: Invalid subgroup or split labels (expected: zero rows).
SELECT applicant_id, protected_group, data_split
FROM applicants
WHERE protected_group NOT IN ('Reference group', 'Comparison group')
   OR data_split NOT IN ('train', 'test');

-- CHECK DQ-05: Population reconciliation (expected: one row, 6,000 total).
SELECT
    COUNT(*) AS total_records,
    SUM(CASE WHEN data_split = 'train' THEN 1 ELSE 0 END) AS train_records,
    SUM(CASE WHEN data_split = 'test' THEN 1 ELSE 0 END) AS test_records
FROM applicants;

-- CHECK DQ-06: Subgroup representation by split (reconciliation).
SELECT
    data_split,
    protected_group,
    COUNT(*) AS record_count,
    ROUND(AVG(qualified_ground_truth), 4) AS qualified_rate,
    ROUND(AVG(historical_selected), 4) AS historical_selection_rate
FROM applicants
GROUP BY data_split, protected_group
ORDER BY data_split, protected_group;
