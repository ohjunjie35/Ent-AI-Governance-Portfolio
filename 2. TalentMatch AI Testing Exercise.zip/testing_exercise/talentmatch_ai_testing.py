#!/usr/bin/env python3
"""Reproducible synthetic testing exercise for an employment-ranking AI system.

This is a portfolio exercise, not a legal compliance opinion or a real bias audit.
It intentionally uses synthetic applicants and an intentionally flawed historical
selection process so that the testing procedures produce findings worth discussing.

Dependencies: numpy, pandas, Pillow (all available in the Codex bundled runtime).
"""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont


SEED = 42001
N_APPLICANTS = 6_000
TRAIN_FRACTION = 0.70
TARGET_SELECTION_RATE = 0.35
OUTPUT_DIR = Path(__file__).resolve().parent / "evidence"

REFERENCE_GROUP = "Reference group"
COMPARISON_GROUP = "Comparison group"

BASELINE_FEATURES = [
    "technical_test",
    "structured_interview",
    "relevant_experience_years",
    "relevant_degree",
    "network_referral",
    "selective_school",
    "career_gap",
]
CHALLENGER_FEATURES = [
    "technical_test",
    "structured_interview",
    "relevant_experience_years",
    "relevant_degree",
]


def sigmoid(values: np.ndarray) -> np.ndarray:
    values = np.clip(values, -35, 35)
    return 1.0 / (1.0 + np.exp(-values))


def fit_logistic_regression(
    x: np.ndarray,
    y: np.ndarray,
    learning_rate: float = 0.08,
    iterations: int = 4_000,
    l2_penalty: float = 0.015,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Fit an interpretable logistic regression with batch gradient descent."""
    means = x.mean(axis=0)
    stds = x.std(axis=0)
    stds[stds == 0] = 1.0
    z = (x - means) / stds
    z = np.column_stack([np.ones(len(z)), z])
    weights = np.zeros(z.shape[1])

    for _ in range(iterations):
        probabilities = sigmoid(z @ weights)
        gradient = (z.T @ (probabilities - y)) / len(y)
        gradient[1:] += l2_penalty * weights[1:]
        weights -= learning_rate * gradient

    return weights, means, stds


def predict_probability(
    x: np.ndarray, weights: np.ndarray, means: np.ndarray, stds: np.ndarray
) -> np.ndarray:
    z = (x - means) / stds
    z = np.column_stack([np.ones(len(z)), z])
    return sigmoid(z @ weights)


def auc_rank(y_true: np.ndarray, scores: np.ndarray) -> float:
    """Compute ROC AUC using the Mann-Whitney rank statistic."""
    y_true = np.asarray(y_true, dtype=int)
    scores = np.asarray(scores, dtype=float)
    positives = int(y_true.sum())
    negatives = len(y_true) - positives
    if positives == 0 or negatives == 0:
        return float("nan")
    ranks = pd.Series(scores).rank(method="average").to_numpy()
    positive_rank_sum = ranks[y_true == 1].sum()
    return float(
        (positive_rank_sum - positives * (positives + 1) / 2)
        / (positives * negatives)
    )


def population_stability_index(
    expected: np.ndarray, actual: np.ndarray, bins: int = 10
) -> float:
    cut_points = np.quantile(expected, np.linspace(0, 1, bins + 1))
    cut_points[0] = -np.inf
    cut_points[-1] = np.inf
    cut_points = np.unique(cut_points)
    expected_counts, _ = np.histogram(expected, bins=cut_points)
    actual_counts, _ = np.histogram(actual, bins=cut_points)
    expected_pct = np.clip(expected_counts / len(expected), 1e-6, None)
    actual_pct = np.clip(actual_counts / len(actual), 1e-6, None)
    return float(np.sum((actual_pct - expected_pct) * np.log(actual_pct / expected_pct)))


def create_population() -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    group = rng.choice(
        [REFERENCE_GROUP, COMPARISON_GROUP], size=N_APPLICANTS, p=[0.50, 0.50]
    )
    comparison = (group == COMPARISON_GROUP).astype(int)

    # Job-related factors have nearly equal distributions by group.
    technical_test = np.clip(rng.normal(73.0 - 0.3 * comparison, 12.0), 25, 100)
    structured_interview = np.clip(
        rng.normal(72.0 + 0.2 * comparison, 11.0), 25, 100
    )
    relevant_experience = np.clip(
        rng.gamma(shape=2.3, scale=1.7, size=N_APPLICANTS), 0, 14
    )
    relevant_degree = rng.binomial(1, 0.68 - 0.01 * comparison)

    # Proxy-like factors intentionally differ by group. They are included to show
    # that simply omitting a protected attribute does not eliminate disparate impact.
    network_referral = rng.binomial(1, 0.47 - 0.25 * comparison)
    selective_school = rng.binomial(1, 0.44 - 0.18 * comparison)
    career_gap = rng.binomial(1, 0.09 + 0.17 * comparison)

    # Synthetic "future job success" is determined only by structured, job-related
    # factors and random uncertainty. It is used solely to evaluate model utility.
    success_logit = (
        -7.15
        + 0.050 * technical_test
        + 0.045 * structured_interview
        + 0.20 * relevant_experience
        + 0.45 * relevant_degree
        + rng.normal(0, 0.55, N_APPLICANTS)
    )
    qualified_probability = sigmoid(success_logit)
    qualified_ground_truth = rng.binomial(1, qualified_probability)

    # Historical selections contain structural bias and overweight non-job-related
    # proxies. The baseline model is trained on these labels.
    historical_logit = (
        -6.20
        + 0.040 * technical_test
        + 0.035 * structured_interview
        + 0.14 * relevant_experience
        + 0.30 * relevant_degree
        + 1.25 * network_referral
        + 0.85 * selective_school
        - 0.95 * career_gap
        - 0.35 * comparison
        + rng.normal(0, 0.75, N_APPLICANTS)
    )
    historical_selected = rng.binomial(1, sigmoid(historical_logit))

    return pd.DataFrame(
        {
            "applicant_id": [f"TM-{i:05d}" for i in range(1, N_APPLICANTS + 1)],
            "protected_group": group,
            "technical_test": technical_test.round(1),
            "structured_interview": structured_interview.round(1),
            "relevant_experience_years": relevant_experience.round(1),
            "relevant_degree": relevant_degree,
            "network_referral": network_referral,
            "selective_school": selective_school,
            "career_gap": career_gap,
            "historical_selected": historical_selected,
            "qualified_ground_truth": qualified_ground_truth,
        }
    )


def threshold_for_target(scores: np.ndarray, target_rate: float) -> float:
    return float(np.quantile(scores, 1.0 - target_rate))


def subgroup_metrics(
    frame: pd.DataFrame, score_col: str, decision_col: str, model_name: str
) -> pd.DataFrame:
    rows = []
    for group_name, subset in frame.groupby("protected_group", sort=False):
        y_true = subset["qualified_ground_truth"].to_numpy()
        decision = subset[decision_col].to_numpy()
        scores = subset[score_col].to_numpy()
        tp = int(((decision == 1) & (y_true == 1)).sum())
        tn = int(((decision == 0) & (y_true == 0)).sum())
        fp = int(((decision == 1) & (y_true == 0)).sum())
        fn = int(((decision == 0) & (y_true == 1)).sum())
        rows.append(
            {
                "model": model_name,
                "protected_group": group_name,
                "n": len(subset),
                "selection_rate": decision.mean(),
                "qualified_rate": y_true.mean(),
                "true_positive_rate": tp / (tp + fn) if tp + fn else np.nan,
                "false_positive_rate": fp / (fp + tn) if fp + tn else np.nan,
                "positive_predictive_value": tp / (tp + fp) if tp + fp else np.nan,
                "brier_score": np.mean((scores - y_true) ** 2),
            }
        )
    return pd.DataFrame(rows)


def overall_metrics(
    frame: pd.DataFrame, score_col: str, decision_col: str, model_name: str
) -> dict[str, float | str]:
    y_true = frame["qualified_ground_truth"].to_numpy()
    decision = frame[decision_col].to_numpy()
    scores = frame[score_col].to_numpy()
    return {
        "model": model_name,
        "n": len(frame),
        "accuracy": float((decision == y_true).mean()),
        "roc_auc": auc_rank(y_true, scores),
        "selection_rate": float(decision.mean()),
        "brier_score": float(np.mean((scores - y_true) ** 2)),
    }


def create_drift_sample(frame: pd.DataFrame) -> pd.DataFrame:
    """Simulate a changed applicant channel and partially missing referral feed."""
    rng = np.random.default_rng(SEED + 99)
    drift = frame.copy()
    drift["technical_test"] = np.clip(
        drift["technical_test"] - rng.normal(6.5, 2.0, len(drift)), 25, 100
    )
    missing_referral = rng.random(len(drift)) < 0.18
    drift.loc[missing_referral, "network_referral"] = np.nan
    drift["network_referral_missing"] = missing_referral.astype(int)
    return drift


def evaluate_test(
    test_id: str,
    domain: str,
    metric: str,
    result: float,
    criterion: str,
    passed: bool,
    severity_if_failed: str,
    interpretation: str,
) -> dict[str, object]:
    return {
        "test_id": test_id,
        "domain": domain,
        "metric": metric,
        "result": result,
        "criterion": criterion,
        "status": "PASS" if passed else "FAIL",
        "severity_if_failed": severity_if_failed,
        "interpretation": interpretation,
    }


def load_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    candidates = [
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf"
        if bold
        else "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/System/Library/Fonts/Supplemental/Helvetica.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
        if bold
        else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for candidate in candidates:
        try:
            return ImageFont.truetype(candidate, size=size)
        except OSError:
            continue
    return ImageFont.load_default()


def create_summary_image(
    subgroup: pd.DataFrame, tests: pd.DataFrame, output_path: Path
) -> None:
    width, height = 1600, 1000
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    navy = "#18324A"
    blue = "#3A6EA5"
    teal = "#2A7F78"
    red = "#B04444"
    gray = "#5D6872"
    pale = "#EAF0F5"
    title_font = load_font(46, bold=True)
    sub_font = load_font(27, bold=True)
    body_font = load_font(23)
    small_font = load_font(20)

    draw.text((70, 48), "TalentMatch AI Testing - Executive Evidence", fill=navy, font=title_font)
    draw.text(
        (72, 112),
        "Synthetic portfolio exercise | Baseline vs. job-related challenger",
        fill=gray,
        font=body_font,
    )

    # Selection-rate comparison.
    draw.rounded_rectangle((65, 175, 960, 585), radius=18, fill=pale)
    draw.text((95, 205), "Subgroup selection rates", fill=navy, font=sub_font)
    plot_left, plot_top, plot_width = 125, 285, 735
    bar_height, row_gap = 42, 92
    ordering = [
        ("Baseline", REFERENCE_GROUP, blue),
        ("Baseline", COMPARISON_GROUP, red),
        ("Challenger", REFERENCE_GROUP, teal),
        ("Challenger", COMPARISON_GROUP, "#71AFA9"),
    ]
    for idx, (model, group, color) in enumerate(ordering):
        value = float(
            subgroup.loc[
                (subgroup["model"] == model)
                & (subgroup["protected_group"] == group),
                "selection_rate",
            ].iloc[0]
        )
        y = plot_top + idx * row_gap
        label = f"{model} - {group.replace(' group', '')}"
        draw.text((plot_left, y - 27), label, fill=navy, font=small_font)
        draw.rounded_rectangle(
            (plot_left, y, plot_left + plot_width, y + bar_height),
            radius=8,
            fill="#D7E0E8",
        )
        draw.rounded_rectangle(
            (plot_left, y, plot_left + int(plot_width * value), y + bar_height),
            radius=8,
            fill=color,
        )
        draw.text(
            (plot_left + plot_width + 18, y + 5),
            f"{value:.1%}",
            fill=navy,
            font=body_font,
        )

    # Test status panel.
    draw.rounded_rectangle((1010, 175, 1535, 585), radius=18, fill="#F6F8FA")
    draw.text((1040, 205), "Control test status", fill=navy, font=sub_font)
    test_rows = tests.loc[tests["status"] == "FAIL"].copy()
    short_metric = {
        "T-01": "Required-feature missingness",
        "T-02": "Predictive utility (ROC AUC)",
        "T-03": "Subgroup impact ratio",
        "T-04": "True-positive-rate gap",
        "T-05": "False-positive-rate gap",
    }
    for idx, (_, row) in enumerate(test_rows.iterrows()):
        y = 274 + idx * 48
        status_color = teal if row["status"] == "PASS" else red
        draw.ellipse((1042, y + 2, 1062, y + 22), fill=status_color)
        draw.text(
            (1080, y - 1),
            f"{row['test_id']}  {short_metric.get(row['test_id'], row['metric'])}",
            fill=navy,
            font=small_font,
        )

    failed = int((tests["status"] == "FAIL").sum())
    passed = int((tests["status"] == "PASS").sum())
    draw.text(
        (1040, 530),
        f"{passed} passed | {failed} failed",
        fill=red if failed else teal,
        font=sub_font,
    )

    # Bottom findings.
    draw.text((72, 650), "Decision and evidence trail", fill=navy, font=sub_font)
    findings = [
        "1. Baseline deployment gate: HOLD - fairness, utility, and input-quality gates fail.",
        "2. Root cause hypothesis: historical-label bias plus referral/school/career-gap proxies.",
        "3. Challenger improves parity using structured, job-related variables; legal and HR validation still required.",
        "4. Evidence retained: data lineage, feature definitions, coefficients, test results, thresholds, and limitations.",
    ]
    y = 710
    for finding in findings:
        draw.text((92, y), finding, fill=navy, font=body_font)
        y += 55
    draw.text(
        (72, 948),
        "Not a real bias audit, employment decision, legal conclusion, or validation of a production system.",
        fill=gray,
        font=small_font,
    )
    image.save(output_path, quality=95)


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    population = create_population()
    rng = np.random.default_rng(SEED + 1)
    shuffled_indices = rng.permutation(len(population))
    train_size = int(len(population) * TRAIN_FRACTION)
    train_indices = shuffled_indices[:train_size]
    test_indices = shuffled_indices[train_size:]
    population["data_split"] = "test"
    population.loc[train_indices, "data_split"] = "train"
    train = population.loc[train_indices].copy()
    test = population.loc[test_indices].copy()

    baseline_model = fit_logistic_regression(
        train[BASELINE_FEATURES].to_numpy(float),
        train["historical_selected"].to_numpy(float),
    )
    baseline_score = predict_probability(
        test[BASELINE_FEATURES].to_numpy(float), *baseline_model
    )
    baseline_threshold = threshold_for_target(
        baseline_score, TARGET_SELECTION_RATE
    )
    test["baseline_score"] = baseline_score
    test["baseline_selected"] = (baseline_score >= baseline_threshold).astype(int)

    # A challenger is trained on synthetic job-success outcomes and restricted to
    # structured, job-related inputs. In a real engagement this change would require
    # industrial-organizational, legal, privacy, and business-owner review.
    challenger_model = fit_logistic_regression(
        train[CHALLENGER_FEATURES].to_numpy(float),
        train["qualified_ground_truth"].to_numpy(float),
    )
    challenger_score = predict_probability(
        test[CHALLENGER_FEATURES].to_numpy(float), *challenger_model
    )
    challenger_threshold = threshold_for_target(
        challenger_score, TARGET_SELECTION_RATE
    )
    test["challenger_score"] = challenger_score
    test["challenger_selected"] = (challenger_score >= challenger_threshold).astype(int)

    baseline_subgroups = subgroup_metrics(
        test, "baseline_score", "baseline_selected", "Baseline"
    )
    challenger_subgroups = subgroup_metrics(
        test, "challenger_score", "challenger_selected", "Challenger"
    )
    subgroup = pd.concat(
        [baseline_subgroups, challenger_subgroups], ignore_index=True
    )

    overall = pd.DataFrame(
        [
            overall_metrics(
                test, "baseline_score", "baseline_selected", "Baseline"
            ),
            overall_metrics(
                test, "challenger_score", "challenger_selected", "Challenger"
            ),
        ]
    )

    def group_value(model: str, group_name: str, metric: str) -> float:
        return float(
            subgroup.loc[
                (subgroup["model"] == model)
                & (subgroup["protected_group"] == group_name),
                metric,
            ].iloc[0]
        )

    baseline_impact_ratio = group_value(
        "Baseline", COMPARISON_GROUP, "selection_rate"
    ) / group_value("Baseline", REFERENCE_GROUP, "selection_rate")
    challenger_impact_ratio = group_value(
        "Challenger", COMPARISON_GROUP, "selection_rate"
    ) / group_value("Challenger", REFERENCE_GROUP, "selection_rate")
    baseline_tpr_gap = abs(
        group_value("Baseline", COMPARISON_GROUP, "true_positive_rate")
        - group_value("Baseline", REFERENCE_GROUP, "true_positive_rate")
    )
    challenger_tpr_gap = abs(
        group_value("Challenger", COMPARISON_GROUP, "true_positive_rate")
        - group_value("Challenger", REFERENCE_GROUP, "true_positive_rate")
    )
    baseline_fpr_gap = abs(
        group_value("Baseline", COMPARISON_GROUP, "false_positive_rate")
        - group_value("Baseline", REFERENCE_GROUP, "false_positive_rate")
    )

    drift = create_drift_sample(test)
    drift_imputed = drift.copy()
    drift_imputed["network_referral"] = drift_imputed["network_referral"].fillna(0)
    drift_score = predict_probability(
        drift_imputed[BASELINE_FEATURES].to_numpy(float), *baseline_model
    )
    score_psi = population_stability_index(baseline_score, drift_score)
    referral_missingness = float(drift["network_referral"].isna().mean())
    drift_auc = auc_rank(
        drift["qualified_ground_truth"].to_numpy(), drift_score
    )
    baseline_auc = float(
        overall.loc[overall["model"] == "Baseline", "roc_auc"].iloc[0]
    )
    auc_drop = baseline_auc - drift_auc

    tests = pd.DataFrame(
        [
            evaluate_test(
                "T-01",
                "Data quality",
                "Required-feature missingness",
                referral_missingness,
                "<= 5.0%",
                referral_missingness <= 0.05,
                "High",
                "Drift sample has an incomplete referral feed; imputation changes model behavior.",
            ),
            evaluate_test(
                "T-02",
                "Performance",
                "Baseline ROC AUC",
                baseline_auc,
                ">= 0.75",
                baseline_auc >= 0.75,
                "High",
                "Discrimination ability against synthetic job-success ground truth.",
            ),
            evaluate_test(
                "T-03",
                "Fairness",
                "Baseline impact ratio",
                baseline_impact_ratio,
                ">= 0.80 and <= 1.25",
                0.80 <= baseline_impact_ratio <= 1.25,
                "Critical",
                "Comparison-group selection rate divided by reference-group selection rate; screening indicator only.",
            ),
            evaluate_test(
                "T-04",
                "Fairness",
                "Baseline true-positive-rate gap",
                baseline_tpr_gap,
                "<= 0.10",
                baseline_tpr_gap <= 0.10,
                "High",
                "Absolute subgroup gap for qualified candidates selected.",
            ),
            evaluate_test(
                "T-05",
                "Fairness",
                "Baseline false-positive-rate gap",
                baseline_fpr_gap,
                "<= 0.10",
                baseline_fpr_gap <= 0.10,
                "High",
                "Absolute subgroup gap for non-qualified candidates selected.",
            ),
            evaluate_test(
                "T-06",
                "Drift",
                "Score population stability index",
                score_psi,
                "< 0.20",
                score_psi < 0.20,
                "High",
                "A value at or above 0.20 triggers investigation; thresholds are portfolio policy choices.",
            ),
            evaluate_test(
                "T-07",
                "Drift",
                "ROC AUC degradation",
                auc_drop,
                "<= 0.05",
                auc_drop <= 0.05,
                "High",
                "Absolute decline from baseline performance under a changed input channel.",
            ),
            evaluate_test(
                "T-08",
                "Mitigation",
                "Challenger impact ratio",
                challenger_impact_ratio,
                ">= 0.80 and <= 1.25",
                0.80 <= challenger_impact_ratio <= 1.25,
                "High",
                "Parity improves after restricting the model to structured, job-related variables.",
            ),
            evaluate_test(
                "T-09",
                "Mitigation",
                "Challenger true-positive-rate gap",
                challenger_tpr_gap,
                "<= 0.10",
                challenger_tpr_gap <= 0.10,
                "High",
                "Residual subgroup difference after the mitigation design.",
            ),
        ]
    )

    baseline_weights, baseline_means, baseline_stds = baseline_model
    challenger_weights, challenger_means, challenger_stds = challenger_model
    coefficients = []
    for model_name, feature_names, weights, means, stds in [
        (
            "Baseline",
            BASELINE_FEATURES,
            baseline_weights,
            baseline_means,
            baseline_stds,
        ),
        (
            "Challenger",
            CHALLENGER_FEATURES,
            challenger_weights,
            challenger_means,
            challenger_stds,
        ),
    ]:
        coefficients.append(
            {
                "model": model_name,
                "feature": "intercept",
                "standardized_coefficient": weights[0],
                "training_mean": np.nan,
                "training_std": np.nan,
            }
        )
        for feature, weight, mean, std in zip(
            feature_names, weights[1:], means, stds
        ):
            coefficients.append(
                {
                    "model": model_name,
                    "feature": feature,
                    "standardized_coefficient": weight,
                    "training_mean": mean,
                    "training_std": std,
                }
            )
    coefficients_df = pd.DataFrame(coefficients)

    evidence_index = pd.DataFrame(
        [
            (
                "E-01",
                "Synthetic applicant population and data dictionary",
                "applicants_synthetic.csv; data_dictionary.csv",
                "Data owner",
            ),
            (
                "E-02",
                "Versioned testing source code and random seed",
                "talentmatch_ai_testing.py",
                "Model validation",
            ),
            (
                "E-03",
                "Model features, coefficients, means, and standard deviations",
                "model_coefficients.csv",
                "Model owner",
            ),
            (
                "E-04",
                "Overall and subgroup performance results",
                "overall_metrics.csv; subgroup_metrics.csv",
                "Independent validator",
            ),
            (
                "E-05",
                "Predefined thresholds, results, and disposition",
                "test_results.csv; run_summary.json",
                "AI risk committee",
            ),
            (
                "E-06",
                "Management-facing visualization",
                "AI_Testing_Summary.png",
                "Engagement lead",
            ),
            (
                "E-07",
                "Scope, limitations, and non-reliance language",
                "README.md; model_card.md; test_plan.md",
                "Independent validator",
            ),
        ],
        columns=["evidence_id", "evidence_description", "artifact", "evidence_owner"],
    )

    data_dictionary = pd.DataFrame(
        [
            ("applicant_id", "Synthetic record identifier", "string", "No"),
            (
                "protected_group",
                "Synthetic subgroup used only for fairness testing; excluded from model inputs",
                "category",
                "Yes",
            ),
            (
                "technical_test",
                "Structured job-related technical assessment (25-100)",
                "numeric",
                "No",
            ),
            (
                "structured_interview",
                "Structured interview score (25-100)",
                "numeric",
                "No",
            ),
            (
                "relevant_experience_years",
                "Relevant experience, capped at 14 years",
                "numeric",
                "No",
            ),
            (
                "relevant_degree",
                "Indicator for a degree relevant to the role",
                "binary",
                "No",
            ),
            (
                "network_referral",
                "Referral indicator; deliberately proxy-like in this exercise",
                "binary",
                "No",
            ),
            (
                "selective_school",
                "Selective-school indicator; deliberately proxy-like",
                "binary",
                "No",
            ),
            (
                "career_gap",
                "Career-gap indicator; deliberately proxy-like",
                "binary",
                "No",
            ),
            (
                "historical_selected",
                "Intentionally biased historical label used to train baseline",
                "binary",
                "No",
            ),
            (
                "qualified_ground_truth",
                "Synthetic future job-success outcome used for testing",
                "binary",
                "No",
            ),
            ("data_split", "Train/test split designation", "category", "No"),
        ],
        columns=["field", "definition", "data_type", "protected_attribute"],
    )

    run_summary = {
        "portfolio_disclaimer": (
            "Synthetic educational exercise only; not a real bias audit, legal "
            "opinion, employment decision, or validation of a production system."
        ),
        "random_seed": SEED,
        "n_applicants": N_APPLICANTS,
        "n_train": len(train),
        "n_test": len(test),
        "target_selection_rate": TARGET_SELECTION_RATE,
        "baseline_threshold": baseline_threshold,
        "challenger_threshold": challenger_threshold,
        "baseline_impact_ratio": baseline_impact_ratio,
        "challenger_impact_ratio": challenger_impact_ratio,
        "baseline_tpr_gap": baseline_tpr_gap,
        "challenger_tpr_gap": challenger_tpr_gap,
        "score_psi": score_psi,
        "referral_missingness_drift_sample": referral_missingness,
        "baseline_auc": baseline_auc,
        "drift_auc": drift_auc,
        "auc_drop": auc_drop,
        "deployment_disposition": (
            "HOLD baseline deployment; investigate data lineage and proxy variables, "
            "validate job relatedness, obtain legal/HR review, retest a controlled challenger, "
            "and define monitoring and human-review procedures."
        ),
    }

    export_population = population.copy()
    export_population.to_csv(OUTPUT_DIR / "applicants_synthetic.csv", index=False)
    data_dictionary.to_csv(OUTPUT_DIR / "data_dictionary.csv", index=False)
    coefficients_df.to_csv(OUTPUT_DIR / "model_coefficients.csv", index=False)
    overall.to_csv(OUTPUT_DIR / "overall_metrics.csv", index=False)
    subgroup.to_csv(OUTPUT_DIR / "subgroup_metrics.csv", index=False)
    tests.to_csv(OUTPUT_DIR / "test_results.csv", index=False)
    evidence_index.to_csv(OUTPUT_DIR / "control_evidence_index.csv", index=False)
    test[
        [
            "applicant_id",
            "protected_group",
            "qualified_ground_truth",
            "baseline_score",
            "baseline_selected",
            "challenger_score",
            "challenger_selected",
        ]
    ].to_csv(OUTPUT_DIR / "scored_test_population.csv", index=False)
    with (OUTPUT_DIR / "run_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(run_summary, handle, indent=2)
    create_summary_image(
        subgroup, tests, OUTPUT_DIR / "AI_Testing_Summary.png"
    )

    print(json.dumps(run_summary, indent=2))
    print("\nTest results")
    print(tests[["test_id", "metric", "result", "criterion", "status"]].to_string(index=False))


if __name__ == "__main__":
    main()
