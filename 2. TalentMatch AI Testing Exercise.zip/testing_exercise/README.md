# TalentMatch AI Testing Exercise

This is a reproducible, synthetic portfolio exercise for testing an AI-assisted
candidate-ranking system. It is designed to demonstrate the mechanics of
independent AI testing, evidence retention, issue escalation, and management
communication in a form relevant to an AI governance or assurance engagement.

It is not a real bias audit, legal opinion, employment decision, certification,
or validation of a production model. The fictional data-generating process
intentionally creates historical-label bias and proxy-variable risk so that the
testing identifies meaningful failures.

## What the exercise demonstrates

1. A seeded Python data-generation and model-testing pipeline over 6,000
   synthetic applicant records.
2. A baseline logistic-ranking model trained on intentionally flawed historical
   decisions while excluding the protected-group field from model inputs.
3. Performance, subgroup, missingness, drift, threshold-sensitivity, and
   mitigation testing.
4. A challenger model limited to structured, job-related features.
5. SQL validation of uniqueness, completeness, validity, population
   reconciliation, and subgroup representation.
6. An evidence index tying data, code, model parameters, thresholds, test
   results, findings, and limitations to accountable owners.

## Reproduce the evidence

Use the Codex bundled Python runtime or any Python 3 environment containing
`numpy`, `pandas`, and `Pillow`.

```bash
python talentmatch_ai_testing.py
python run_sql_validation.py
```

The scripts write their outputs to `evidence/`. The random seed is fixed at
42001, and the code retains model coefficients, standardization parameters,
subgroup results, the scored test population, and the deployment disposition.

## Results in this run

- Baseline impact ratio: 0.534 (failed the exercise's 0.80-1.25 gate).
- Baseline true-positive-rate gap: 0.244 (failed the 0.10 gate).
- Baseline ROC AUC: 0.623 (failed the 0.75 gate).
- Drift-sample referral missingness: 18.3% (failed the 5% gate).
- Challenger impact ratio: 0.841 (passed the exercise gate).
- Challenger true-positive-rate gap: 0.089 (passed the exercise gate).

The baseline disposition is **HOLD**. The fictional management team should
investigate the label and feature lineage, validate job relatedness, obtain HR
and legal review, remove or justify proxy-like variables, retest a controlled
challenger, document human oversight and appeals, and define production
monitoring before deployment.

The 0.80 impact-ratio threshold is used only as a screening indicator in this
portfolio. Passing it does not establish fairness or legal compliance, and
failing it is not by itself a legal conclusion. Context, sample size, job
relatedness, business necessity, intersectional analysis, accommodations, and
less-discriminatory alternatives require further assessment.

## Evidence map

- `talentmatch_ai_testing.py`: seeded generation, model training, metrics, drift
  simulation, test evaluation, and executive visual.
- `data_validation.sql` and `run_sql_validation.py`: SQL quality controls.
- `applicants_synthetic.csv` and `data_dictionary.csv`: source population and
  definitions.
- `model_coefficients.csv`: interpretable model parameters.
- `overall_metrics.csv` and `subgroup_metrics.csv`: model and subgroup evidence.
- `test_results.csv`: test criteria, results, status, severity, and
  interpretation.
- `control_evidence_index.csv`: artifact-to-owner traceability.
- `run_summary.json`: decision-ready metrics and disposition.
- `AI_Testing_Summary.png`: management-facing summary.

## Framework relevance

The test plan supports the NIST AI RMF's GOVERN, MAP, MEASURE, and MANAGE
functions and the testing, monitoring, documentation, and accountability
capabilities of an ISO/IEC 42001-aligned AI management system. Employment uses
also warrant jurisdiction-specific analysis. In this fictional case, the EU AI
Act, U.S. employment-discrimination law, and New York City Local Law 144 are
treated as applicability-screening inputs, not as compliance conclusions.

Primary references:

- NIST AI RMF: https://www.nist.gov/itl/ai-risk-management-framework
- NIST AI RMF 1.0: https://doi.org/10.6028/NIST.AI.100-1
- ISO/IEC 42001 overview: https://www.iso.org/standard/42001
- EU AI Act: https://eur-lex.europa.eu/eli/reg/2024/1689/oj/eng
- EEOC selection procedures: https://www.eeoc.gov/laws/guidance/employment-tests-and-selection-procedures
- NYC automated employment decision tools: https://www.nyc.gov/site/dca/about/automated-employment-decision-tools.page
