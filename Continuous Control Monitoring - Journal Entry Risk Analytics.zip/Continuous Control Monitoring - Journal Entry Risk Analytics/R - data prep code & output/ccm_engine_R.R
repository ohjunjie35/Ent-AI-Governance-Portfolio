# CCM Engine (R) - clean and flag general-ledger journal entries.
# COMPSCI X465.1 Data Visualization, Final Project.
#
# Run:  Rscript ccm_engine_R.R      (or source() it in RStudio)
# Reads journal_entries_raw.csv, writes journal_entries_clean_R.csv, and prints the
# row counts and exception totals at each step. Base R only - no extra packages.
# This is an independent re-clean of the same raw file used by the Python version;
# the row count and flag totals should match.

RAW_PATH <- "../Raw data (synthetic)/journal_entries_raw.csv"
OUT_PATH <- "journal_entries_clean_R.csv"

# ---------------------------------------------------------------------------
# STEP 1 - Load and inspect the raw data
# ---------------------------------------------------------------------------
# na.strings = c("", "NA") so blank cells (e.g. missing approver/amount) read as
# NA rather than an empty string.
df <- read.csv(RAW_PATH, stringsAsFactors = FALSE, na.strings = c("", "NA"))

cat("Rows x Cols:", nrow(df), "x", ncol(df), "\n")
cat("\nentry_type raw values:\n"); print(table(df$entry_type, useNA = "ifany"))
cat("\nbusiness_unit raw values:\n"); print(table(df$business_unit, useNA = "ifany"))
cat("\nMissing per column:\n"); print(colSums(is.na(df)))

# ---------------------------------------------------------------------------
# STEP 2 - Standardize text (case + whitespace)
# ---------------------------------------------------------------------------
# Trim whitespace on the text columns. trimws() leaves NA as NA.
for (col in c("business_unit", "entry_type", "preparer", "approver")) {
  df[[col]] <- trimws(df[[col]])
}

# business_unit -> EMEA / APAC / Americas. Upper-case first (title case would give
# "Emea"/"Apac"), then fix the one real word.
df$business_unit <- toupper(df$business_unit)
df$business_unit[df$business_unit == "AMERICAS"] <- "Americas"

# entry_type -> Manual / Automated (first letter upper, rest lower).
# ifelse guard keeps an NA as NA (paste0 would otherwise turn it into "NANA").
capitalize <- function(x) ifelse(is.na(x), NA,
                                 paste0(toupper(substring(x, 1, 1)), tolower(substring(x, 2))))
df$entry_type <- capitalize(df$entry_type)

cat("\n=== STEP 2: after standardizing ===\n")
cat("business_unit ->\n"); print(table(df$business_unit))
cat("entry_type ->\n"); print(table(df$entry_type))

# ---------------------------------------------------------------------------
# STEP 3 - Handle blanks
# ---------------------------------------------------------------------------
# Treat a whitespace-only approver as blank too, then flag the blanks.
df$approver[!is.na(df$approver) & df$approver == ""] <- NA

# Missing approver = a finding, not a gap: keep the row, record it as a flag.
# Set the flag before dropping any rows so it stays accurate.
df$approver_missing <- is.na(df$approver)
cat("\n=== STEP 3: handling blanks ===\n")
cat("Unapproved entries flagged (kept, not deleted):", sum(df$approver_missing), "\n")

# Missing amount can't be tested against any dollar rule, so drop those rows.
missing_amount <- sum(is.na(df$amount))
rows_before <- nrow(df)
df <- df[!is.na(df$amount), ]
cat("Rows missing amount:", missing_amount, "-> dropped\n")
cat("Row count:", rows_before, "->", nrow(df), "\n")

# ---------------------------------------------------------------------------
# STEP 4 - Drop exact duplicates
# ---------------------------------------------------------------------------
# entry_id is unique on every row, so a duplicate posting carries a new ID.
# Compare on every column except entry_id; a full match is the same entry twice.
compare_cols <- c("entry_date", "posting_date", "period", "account",
                  "business_unit", "amount", "entry_type", "preparer",
                  "approver", "description")

dupe_count <- sum(duplicated(df[compare_cols]))
rows_before <- nrow(df)
df <- df[!duplicated(df[compare_cols]), ]
cat("\n=== STEP 4: duplicates ===\n")
cat("Duplicate rows dropped:", dupe_count, "\n")
cat("Row count:", rows_before, "->", nrow(df), "\n")

# ---------------------------------------------------------------------------
# STEP 5a - Timing flags (backdating, weekend)
# ---------------------------------------------------------------------------
df$entry_date <- as.Date(df$entry_date)
df$posting_date <- as.Date(df$posting_date)

# days_to_post: days between the transaction date and when it was posted.
df$days_to_post <- as.integer(df$posting_date - df$entry_date)

# is_backdated: posted 30+ days late (a full accounting period).
df$is_backdated <- df$days_to_post >= 30

# is_weekend: use POSIXlt$wday (0 = Sunday, 6 = Saturday) to avoid locale issues.
# posting_weekday keeps the readable day name for reference.
df$posting_weekday <- weekdays(df$posting_date)
df$is_weekend <- as.POSIXlt(df$posting_date)$wday %in% c(0, 6)

cat("\n=== STEP 5a: timing flags ===\n")
cat("Backdated (>=30 days late):", sum(df$is_backdated), "\n")
cat("Weekend postings:", sum(df$is_weekend), "\n")

# ---------------------------------------------------------------------------
# STEP 5b - Amount and behaviour flags
# ---------------------------------------------------------------------------
# is_round_dollar: exact multiple of 25,000. %% is the modulo (remainder).
df$is_round_dollar <- (df$amount %% 25000 == 0) & (df$amount > 0)

# is_large_manual: Manual entry over 30,000.
df$is_large_manual <- (df$entry_type == "Manual") & (df$amount > 30000)

# sod_conflict: preparer approved their own entry. Guard with !is.na so a blank
# approver is FALSE here (that case is covered by approver_missing).
df$sod_conflict <- !is.na(df$approver) & (df$preparer == df$approver)

# unusual_user: preparer with far-below-normal activity. Flag any preparer with
# fewer than 25% of the median preparer's entries, so it isn't tied to one name.
prep_tab <- table(df$preparer)
prep_counts <- as.integer(prep_tab[df$preparer])
cutoff <- 0.25 * median(as.integer(prep_tab))
df$unusual_user <- prep_counts < cutoff

cat("\n=== STEP 5b: amount & behaviour flags ===\n")
cat("Round-dollar entries:", sum(df$is_round_dollar), "\n")
cat("Large manual (>30k):", sum(df$is_large_manual), "\n")
cat("Self-approval (SoD) conflicts:", sum(df$sod_conflict), "\n")
cat("Unusual-user entries:", sum(df$unusual_user), "\n")

# flag_count: how many flags each entry trips. as.integer keeps it a whole number
# (rowSums returns a double) to match the Python output.
flag_cols <- c("approver_missing", "is_backdated", "is_weekend",
               "is_round_dollar", "is_large_manual", "sod_conflict", "unusual_user")
df$flag_count <- as.integer(rowSums(df[flag_cols]))
cat("\nEntries with at least one flag:", sum(df$flag_count > 0), "\n")
cat("Flag-count distribution:\n"); print(table(df$flag_count))

# ---------------------------------------------------------------------------
# STEP 6 - Save the cleaned + enriched data
# ---------------------------------------------------------------------------
# Reorder columns to match the Python output, then write. row.names = FALSE keeps
# R's row numbers out of the file.
col_order <- c("entry_id", "entry_date", "posting_date", "period", "account",
               "business_unit", "amount", "entry_type", "preparer", "approver",
               "description", "approver_missing", "days_to_post", "is_backdated",
               "posting_weekday", "is_weekend", "is_round_dollar", "is_large_manual",
               "sod_conflict", "unusual_user", "flag_count")
df <- df[, col_order]
write.csv(df, OUT_PATH, row.names = FALSE)
cat("\n=== STEP 6: saved ===\n")
cat("Wrote", nrow(df), "rows x", ncol(df), "columns ->", OUT_PATH, "\n")
