"""
CCM Visualization (Python / Plotly) - full-population risk scatter.
COMPSCI X465.1 Data Visualization, Final Project.

Run: python ccm_visualize_python.py
Reads journal_entries_clean_python.csv and writes ccm_visualization_python.html: one dot
per entry, coloured by how many flags it trips. See ../OVERVIEW_ READ ME FIRST.txt for details.

Interactive controls in the output:
  - Filter dropdown: slice the population by region, entry type, or risk level.
  - Legend: click a risk level (0-3 flags) to show/hide it.
  - Hover: full entry detail. Drag to zoom a date range or amount band.
"""

import pandas as pd
import plotly.graph_objects as go

CLEAN_PATH = "../Python - data prep code & output/journal_entries_clean_python.csv"
OUT_HTML = "ccm_visualization_python.html"

# ---------------------------------------------------------------------------
# 1. Load the cleaned data. The CSV stores dates as text, so re-parse posting_date.
# ---------------------------------------------------------------------------
df = pd.read_csv(CLEAN_PATH)
df["posting_date"] = pd.to_datetime(df["posting_date"])

# ---------------------------------------------------------------------------
# 2. "Flags fired" text for the hover, and per-point marker shape by entry type.
# ---------------------------------------------------------------------------
flag_labels = {
    "approver_missing": "No approver",
    "is_backdated": "Backdated 30+ days",
    "is_weekend": "Weekend posting",
    "is_round_dollar": "Round-dollar amount",
    "is_large_manual": "Large manual (>30k)",
    "sod_conflict": "Self-approval (SoD)",
    "unusual_user": "Unusual user",
}

def flags_fired(row):
    fired = [label for col, label in flag_labels.items() if row[col]]
    return ", ".join(fired) if fired else "None"

df["flags_fired"] = df.apply(flags_fired, axis=1)
# Unknown entry types fall back to a circle so a stray value can't break the marker.
df["symbol"] = df["entry_type"].map({"Manual": "diamond", "Automated": "circle"}).fillna("circle")
# A blank approver reads as NaN; show "(none)" in the hover instead of "nan".
df["approver_display"] = df["approver"].fillna("(none)")

# Fields shown on hover, in this order.
HOVER_COLS = ["entry_id", "preparer", "approver_display", "business_unit",
              "account", "amount", "days_to_post", "flags_fired"]
HOVER_TMPL = (
    "<b>%{customdata[0]}</b><br>"
    "Amount: $%{customdata[5]:,.2f}<br>"
    "Posted: %{x|%Y-%m-%d} (%{customdata[6]} days after entry)<br>"
    "Region: %{customdata[3]} | Account: %{customdata[4]}<br>"
    "Preparer: %{customdata[1]} | Approver: %{customdata[2]}<br>"
    "Flags: %{customdata[7]}<extra></extra>"
)

# ---------------------------------------------------------------------------
# 3. One trace per risk level (0-3 flags) so the legend toggles by risk. Colour
#    encodes risk (grey -> red); marker shape encodes Manual (diamond) vs
#    Automated (circle).
# ---------------------------------------------------------------------------
CLASS_COLOR = {0: "#c9ccd1", 1: "#f4c430", 2: "#f08a24", 3: "#d62728"}
CLASSES = [0, 1, 2, 3]

def subset_arrays(sub):
    """Return the plot arrays for one risk-level subset (used by the filter buttons)."""
    return dict(
        x=sub["posting_date"], y=sub["amount"],
        customdata=sub[HOVER_COLS].values, symbol=sub["symbol"],
    )

fig = go.Figure()
for c in CLASSES:
    s = subset_arrays(df[df["flag_count"] == c])
    fig.add_trace(go.Scatter(
        x=s["x"], y=s["y"], customdata=s["customdata"],
        mode="markers", name=f"{c} flag" + ("s" if c != 1 else ""),
        marker=dict(color=CLASS_COLOR[c], size=9, symbol=s["symbol"],
                    line=dict(width=0.5, color="white")),
        opacity=0.9, hovertemplate=HOVER_TMPL,
    ))

# ---------------------------------------------------------------------------
# 4. Filter dropdown - each option re-plots all four traces on a data subset,
#    so the viewer can slice the population and see where exceptions concentrate.
# ---------------------------------------------------------------------------
PRESETS = {
    "All entries": df["entry_id"].notna(),
    "Region: EMEA": df["business_unit"] == "EMEA",
    "Region: APAC": df["business_unit"] == "APAC",
    "Region: Americas": df["business_unit"] == "Americas",
    "Type: Manual only": df["entry_type"] == "Manual",
    "Type: Automated only": df["entry_type"] == "Automated",
    "Flagged only (1+)": df["flag_count"] >= 1,
    "Highest risk (2+)": df["flag_count"] >= 2,
}

buttons = []
for name, mask in PRESETS.items():
    sub = df[mask]
    xs, ys, cds, syms = [], [], [], []
    for c in CLASSES:
        s = subset_arrays(sub[sub["flag_count"] == c])
        xs.append(s["x"]); ys.append(s["y"])
        cds.append(s["customdata"]); syms.append(s["symbol"])
    buttons.append(dict(
        label=f"{name}  (n={len(sub)})", method="restyle",
        args=[{"x": xs, "y": ys, "customdata": cds, "marker.symbol": syms},
              [0, 1, 2, 3]],
    ))

fig.update_layout(
    template="plotly_white",
    height=720,
    margin=dict(t=130, b=150),
    legend_title_text="Flags tripped",
    title=dict(
        text="Journal-Entry Exception Monitoring — Full Population (594 entries)",
        x=0.5, xanchor="center", y=0.98, yanchor="top", font_size=17,
    ),
    xaxis_title="Posting date",
    yaxis_title="Entry amount ($)",
    updatemenus=[dict(
        buttons=buttons, direction="down", showactive=True, active=0,
        x=0.0, xanchor="left", y=1.10, yanchor="top",
        pad=dict(l=2, t=2), bgcolor="white", bordercolor="#cccccc",
    )],
)

# Dropdown label (sits just above the dropdown, top-left).
fig.add_annotation(xref="paper", yref="paper", x=0.0, y=1.16, showarrow=False,
                   text="<b>Filter view:</b>", font=dict(size=12), xanchor="left")

# Findings caption under the chart, so the output states how the question is answered.
fig.add_annotation(
    xref="paper", yref="paper", x=0, y=-0.24, showarrow=False, align="left",
    font=dict(size=11, color="#444"),
    text=("81 of 594 entries (14%) are flagged; risk concentrates in manual entries "
          "(~6x the automated rate), peaking in large weekend entries with an "
          "authorization gap.  Shape: ◆ manual, ● automated.<br>"
          "Answer: the highest-risk entries are the 8 red, three-flag points - large, "
          "manual, weekend postings with a missing or self-approval. Full-population "
          "testing surfaces all 81; sampling would likely miss most."),
)

fig.write_html(OUT_HTML, include_plotlyjs="cdn")
print(f"Saved interactive chart -> {OUT_HTML}")
print("Open it in a browser. Use the Filter dropdown, legend, hover and zoom to explore.")
