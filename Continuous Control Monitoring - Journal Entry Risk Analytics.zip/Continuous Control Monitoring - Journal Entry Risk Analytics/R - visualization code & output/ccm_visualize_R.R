# CCM Visualization (R / ggplot2) - full-population risk scatter (static).
# COMPSCI X465.1 Data Visualization, Final Project.
#
# Run:  Rscript ccm_visualize_R.R     (or source() it in RStudio)
# Reads journal_entries_clean_R.csv and writes ccm_visualization_R.png: one point
# per entry, coloured by how many flags it trips. Needs ggplot2.

# install.packages("ggplot2")   # uncomment on first run if not installed
library(ggplot2)

CLEAN_PATH <- "../R - data prep code & output/journal_entries_clean_R.csv"
OUT_PNG <- "ccm_visualization_R.png"

df <- read.csv(CLEAN_PATH, stringsAsFactors = FALSE)
df$posting_date <- as.Date(df$posting_date)

# Draw clean (0-flag) points first so the red high-risk points sit on top.
df <- df[order(df$flag_count), ]

# flag_count as an ordered factor drives the colour legend (0-3).
df$Flags <- factor(df$flag_count, levels = c(0, 1, 2, 3))

# Colour encodes risk (grey -> red); shape encodes Manual (diamond) vs Automated
# (circle). 18 = filled diamond, 16 = filled circle.
flag_colors <- c("0" = "#c9ccd1", "1" = "#f4c430", "2" = "#f08a24", "3" = "#d62728")
type_shapes <- c("Manual" = 18, "Automated" = 16)

p <- ggplot(df, aes(x = posting_date, y = amount, color = Flags, shape = entry_type)) +
  geom_point(size = 2.4, alpha = 0.85) +
  scale_color_manual(values = flag_colors, name = "Flags tripped") +
  scale_shape_manual(values = type_shapes, name = "Entry type") +
  scale_y_continuous(labels = function(v) paste0(v / 1000, "k")) +
  labs(
    title = "Journal-Entry Exception Monitoring — Full Population (594 entries)",
    subtitle = paste("81 of 594 entries flagged (14%). Risk concentrates in manual entries",
                     "(~6x the automated rate),\npeaking in large weekend entries with an authorization gap."),
    x = "Posting date", y = "Entry amount ($)",
    caption = paste("Answer: the highest-risk entries are the 8 red (three-flag) points - large, manual,",
                    "weekend postings with a missing or self-approval.\nFull-population testing surfaces",
                    "all 81 exceptions; sample-based testing would likely miss most.")
  ) +
  theme_minimal(base_size = 12) +
  theme(
    plot.title = element_text(face = "bold"),
    plot.caption = element_text(hjust = 0, size = 8, color = "grey30"),
    plot.subtitle = element_text(size = 10, color = "grey30")
  )

ggsave(OUT_PNG, p, width = 11, height = 6.5, dpi = 150)
cat("Saved chart ->", OUT_PNG, "\n")
