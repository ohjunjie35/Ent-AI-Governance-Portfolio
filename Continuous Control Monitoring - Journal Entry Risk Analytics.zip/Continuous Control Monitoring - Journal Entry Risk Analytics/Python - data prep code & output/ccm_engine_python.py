"""
CCM Engine - clean and flag general-ledger journal entries.
COMPSCI X465.1 Data Visualization, Final Project.

Run: python ccm_engine_python.py
Reads journal_entries_raw.csv, writes journal_entries_clean_python.csv, and prints the
row counts and exception totals at each step. Full pipeline and flag definitions
are in ../OVERVIEW_ READ ME FIRST.txt.
"""

import pandas as pd

RAW_PATH = "../Raw data (synthetic)/journal_entries_raw.csv"


# ---------------------------------------------------------------------------
# STEP 1 - Load and inspect the raw data
# ---------------------------------------------------------------------------
# Look before changing anything: types, value counts, blanks.

df = pd.read_csv(RAW_PATH)

print("SHAPE (rows, columns):", df.shape)

print("\n--- Column names & data types ---")
print(df.dtypes)

print("\n--- First 5 rows ---")
print(df.head())

print("\n--- business_unit: raw value counts (watch for case + trailing spaces) ---")
print(df["business_unit"].value_counts(dropna=False))

print("\n--- entry_type: raw value counts ---")
print(df["entry_type"].value_counts(dropna=False))

print("\n--- Missing values per column ---")
print(df.isna().sum())

# repr() makes a trailing space visible: 'EMEA ' vs 'EMEA'.
print("\n--- Unique business_unit values shown with quotes (spot the spaces) ---")
print([repr(v) for v in df["business_unit"].unique()])


# ---------------------------------------------------------------------------
# STEP 2 - Standardize text (case + whitespace)
# ---------------------------------------------------------------------------
# Collapse the variants so "emea", "EMEA " and "EMEA" count as one region.

# Trim whitespace. strip() leaves NaN alone, which is what I want for approver.
for col in ["business_unit", "entry_type", "preparer", "approver"]:
    df[col] = df[col].str.strip()

# business_unit -> EMEA / APAC / Americas. Upper-case first (using .title() would
# turn the acronyms into "Emea"/"Apac"), then fix the one real word.
df["business_unit"] = df["business_unit"].str.upper().replace({"AMERICAS": "Americas"})

# entry_type -> Manual / Automated.
df["entry_type"] = df["entry_type"].str.capitalize()

print("\n=== STEP 2: after standardizing ===")
print("business_unit ->")
print(df["business_unit"].value_counts(dropna=False))
print("\nentry_type ->")
print(df["entry_type"].value_counts(dropna=False))


# ---------------------------------------------------------------------------
# STEP 3 - Handle blanks
# ---------------------------------------------------------------------------
# Missing approver and missing amount get opposite treatment.

# Missing approver is a finding, not a gap: an unapproved entry. Keep the row and
# record it as a flag. Set the flag before dropping anything so it stays accurate.
df["approver_missing"] = df["approver"].isna()
print("\n=== STEP 3: handling blanks ===")
print("Unapproved entries flagged (kept, not deleted):", df["approver_missing"].sum())

# Missing amount can't be tested against any dollar rule, so drop those rows.
# Count them first for the writeup.
missing_amount = df["amount"].isna().sum()
rows_before = len(df)
df = df[df["amount"].notna()].copy()
print(f"Rows missing amount: {missing_amount} -> dropped")
print(f"Row count: {rows_before} -> {len(df)}")


# ---------------------------------------------------------------------------
# STEP 4 - Drop exact duplicates
# ---------------------------------------------------------------------------
# entry_id is unique on every row, so a duplicate posting carries a new ID.
# Compare on everything except entry_id; a full match is the same entry twice.

compare_cols = [
    "entry_date", "posting_date", "period", "account", "business_unit",
    "amount", "entry_type", "preparer", "approver", "description",
]

# keep="first" marks every duplicate after the first occurrence.
dupe_count = df.duplicated(subset=compare_cols, keep="first").sum()

rows_before = len(df)
df = df.drop_duplicates(subset=compare_cols, keep="first").copy()
print("\n=== STEP 4: duplicates ===")
print(f"Duplicate rows dropped: {dupe_count}")
print(f"Row count: {rows_before} -> {len(df)}")


# ---------------------------------------------------------------------------
# STEP 5a - Timing flags (backdating, weekend)
# ---------------------------------------------------------------------------
# Convert the date columns to real dates first, then derive the timing flags.

df["entry_date"] = pd.to_datetime(df["entry_date"])
df["posting_date"] = pd.to_datetime(df["posting_date"])

# days_to_post: days between the transaction date and when it was posted.
df["days_to_post"] = (df["posting_date"] - df["entry_date"]).dt.days

# is_backdated: posted 30+ days late. Normal entries post within ~3 days and the
# late cluster sits at 35-59, so a 30-day cutoff isolates it without false hits.
df["is_backdated"] = df["days_to_post"] >= 30

# is_weekend: posted on a Saturday (5) or Sunday (6).
df["posting_weekday"] = df["posting_date"].dt.day_name()
df["is_weekend"] = df["posting_date"].dt.dayofweek >= 5

print("\n=== STEP 5a: timing flags ===")
print("Backdated (>=30 days late):", df["is_backdated"].sum())
print("Weekend postings:", df["is_weekend"].sum())


# ---------------------------------------------------------------------------
# STEP 5b - Amount and behaviour flags
# ---------------------------------------------------------------------------

# is_round_dollar: exact multiple of 25,000. Real invoices aren't round, so a
# round manual figure points to a hand-typed estimate or plug.
df["is_round_dollar"] = (df["amount"] % 25000 == 0) & (df["amount"] > 0)

# is_large_manual: Manual entry over 30,000. Manual entries skip system checks.
df["is_large_manual"] = (df["entry_type"] == "Manual") & (df["amount"] > 30000)

# sod_conflict: preparer approved their own entry (self-approval). A blank
# approver stays False here; that case is covered by approver_missing.
df["sod_conflict"] = df["preparer"] == df["approver"]

# unusual_user: preparer with far-below-normal activity, e.g. a temp. Flag any
# preparer with fewer than 25% of the median preparer's entries, so it isn't
# tied to one name.
prep_counts = df["preparer"].map(df["preparer"].value_counts())
cutoff = 0.25 * df["preparer"].value_counts().median()
df["unusual_user"] = prep_counts < cutoff

print("\n=== STEP 5b: amount & behaviour flags ===")
print("Round-dollar entries:", df["is_round_dollar"].sum())
print("Large manual (>30k):", df["is_large_manual"].sum())
print("Self-approval (SoD) conflicts:", df["sod_conflict"].sum())
print("Unusual-user entries:", df["unusual_user"].sum())

# flag_count: how many flags each entry trips. Used to rank entries and to colour
# the chart.
flag_cols = ["approver_missing", "is_backdated", "is_weekend",
             "is_round_dollar", "is_large_manual", "sod_conflict", "unusual_user"]
df["flag_count"] = df[flag_cols].sum(axis=1)
print("\nEntries with at least one flag:", (df["flag_count"] > 0).sum())
print("Flag-count distribution:")
print(df["flag_count"].value_counts().sort_index())


# ---------------------------------------------------------------------------
# STEP 6 - Save the cleaned + enriched data
# ---------------------------------------------------------------------------
# index=False keeps pandas' row numbers out of the file.

OUT_PATH = "journal_entries_clean_python.csv"
df.to_csv(OUT_PATH, index=False)
print(f"\n=== STEP 6: saved ===")
print(f"Wrote {len(df)} rows x {df.shape[1]} columns -> {OUT_PATH}")
print("Columns:", list(df.columns))
