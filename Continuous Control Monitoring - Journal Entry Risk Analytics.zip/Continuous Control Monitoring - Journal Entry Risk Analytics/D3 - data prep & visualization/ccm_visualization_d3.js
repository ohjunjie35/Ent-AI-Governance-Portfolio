// CCM Visualization (D3.js) - in-browser data prep + interactive scatter.
// COMPSCI X465.1 Data Visualization, Final Project.
// Loaded by ccm_visualization_d3.html (which embeds the raw data).

// =====================================================================
// 1. PREPARE THE DATA (in-browser cleaning + flagging, mirroring the
//    Python and R engines). This is the D3.js "prepare data" step.
// =====================================================================
const rawText = document.getElementById("raw").textContent.trim();
let rows = d3.csvParse(rawText);

const cap = s => s ? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase() : s;
const asUTC = s => { const [y, m, d] = s.split("-").map(Number); return Date.UTC(y, m - 1, d); };

// 1a. Standardize text (case + whitespace).
rows.forEach(r => {
  ["business_unit", "entry_type", "preparer", "approver"].forEach(k => r[k] = (r[k] || "").trim());
  r.business_unit = r.business_unit.toUpperCase();
  if (r.business_unit === "AMERICAS") r.business_unit = "Americas";
  r.entry_type = cap(r.entry_type);
  r.approver_missing = r.approver === "";      // blank approver = a finding
});

// 1b. Drop rows with no amount (can't be tested against any dollar rule).
rows = rows.filter(r => r.amount !== "" && r.amount != null);

// 1c. Drop exact duplicates (match on every field except the unique entry_id).
const cmp = ["entry_date", "posting_date", "period", "account", "business_unit",
             "amount", "entry_type", "preparer", "approver", "description"];
const seen = new Set();
rows = rows.filter(r => {
  const key = cmp.map(c => r[c]).join("|");
  if (seen.has(key)) return false;
  seen.add(key); return true;
});

// 1d. Derive the audit flags.
rows.forEach(r => {
  r.amount = +r.amount;
  r.postDate = new Date(asUTC(r.posting_date));
  r.days_to_post = Math.round((asUTC(r.posting_date) - asUTC(r.entry_date)) / 864e5);
  r.is_backdated = r.days_to_post >= 30;
  const wd = r.postDate.getUTCDay();
  r.is_weekend = (wd === 0 || wd === 6);
  r.is_round_dollar = (r.amount % 25000 === 0 && r.amount > 0);
  r.is_large_manual = (r.entry_type === "Manual" && r.amount > 30000);
  r.sod_conflict = (r.approver !== "" && r.preparer === r.approver);
});
// unusual_user: preparer with < 25% of the median preparer's activity.
const counts = {};
rows.forEach(r => counts[r.preparer] = (counts[r.preparer] || 0) + 1);
const vals = Object.values(counts).sort((a, b) => a - b);
const median = vals.length % 2 ? vals[(vals.length - 1) / 2]
                               : (vals[vals.length / 2 - 1] + vals[vals.length / 2]) / 2;
const cutoff = 0.25 * median;
const FLAGS = {
  approver_missing: "No approver", is_backdated: "Backdated 30+ days",
  is_weekend: "Weekend posting", is_round_dollar: "Round-dollar amount",
  is_large_manual: "Large manual (>30k)", sod_conflict: "Self-approval (SoD)",
  unusual_user: "Unusual user"
};
rows.forEach(r => {
  r.unusual_user = counts[r.preparer] < cutoff;
  r.flag_count = Object.keys(FLAGS).reduce((s, k) => s + (r[k] ? 1 : 0), 0);
  r.flags_fired = Object.keys(FLAGS).filter(k => r[k]).map(k => FLAGS[k]).join(", ") || "None";
});

// =====================================================================
// 2. DRAW THE INTERACTIVE SCATTER
// =====================================================================
const margin = { top: 20, right: 20, bottom: 50, left: 70 },
      width = 1000 - margin.left - margin.right,
      height = 540 - margin.top - margin.bottom;

const svg = d3.select("#chart").append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
  .append("g")
    .attr("transform", `translate(${margin.left},${margin.top})`);

const x = d3.scaleTime().domain(d3.extent(rows, d => d.postDate)).range([0, width]).nice();
const y = d3.scaleLinear().domain([0, d3.max(rows, d => d.amount) * 1.05]).range([height, 0]);
const color = d3.scaleOrdinal().domain([0, 1, 2, 3])
    .range(["#c9ccd1", "#f4c430", "#f08a24", "#d62728"]);
const shape = d => d3.symbol()
    .type(d.entry_type === "Manual" ? d3.symbolDiamond : d3.symbolCircle).size(70)();

svg.append("g").attr("transform", `translate(0,${height})`)
    .call(d3.axisBottom(x));
svg.append("g")
    .call(d3.axisLeft(y).tickFormat(d => "$" + d3.format(",")(d)));

svg.append("text").attr("class", "axis-label")
    .attr("x", width / 2).attr("y", height + 40).attr("text-anchor", "middle")
    .text("Posting date");
svg.append("text").attr("class", "axis-label")
    .attr("transform", "rotate(-90)").attr("x", -height / 2).attr("y", -55)
    .attr("text-anchor", "middle").text("Entry amount ($)");

const tooltip = d3.select("#tooltip");
const fmt = d3.format(",.2f");

// Legend-driven highlight: click a flag level to emphasize those points and dim
// the rest (mirrors clicking a flag band in the Python chart). null = show all.
let isolated = null;
const pointOpacity = d => isolated === null ? 0.9 : (d.flag_count === isolated ? 0.95 : 0.06);
function refreshHighlight() {
  svg.selectAll("path.pt").attr("opacity", pointOpacity);
  if (isolated !== null)
    svg.selectAll("path.pt").filter(d => d.flag_count === isolated).raise();
  legend.selectAll("span.legend-item")
    .style("opacity", function () {
      const lv = +this.getAttribute("data-level");
      return (isolated === null || isolated === lv) ? 1 : 0.35;
    })
    .style("font-weight", function () {
      return (+this.getAttribute("data-level") === isolated) ? "600" : "normal";
    });
}

function render(data) {
  // Draw clean points first so high-risk points sit on top.
  data = data.slice().sort((a, b) => a.flag_count - b.flag_count);

  const pts = svg.selectAll("path.pt").data(data, d => d.entry_id);
  pts.exit().remove();
  pts.enter().append("path").attr("class", "pt")
      .attr("stroke", "white").attr("stroke-width", 0.5)
    .merge(pts)
      .attr("d", shape)
      .attr("transform", d => `translate(${x(d.postDate)},${y(d.amount)})`)
      .attr("fill", d => color(d.flag_count))
      .attr("opacity", pointOpacity)
      .on("mouseover", (event, d) => {
        tooltip.style("opacity", 1).html(
          `<b>${d.entry_id}</b><br>` +
          `Amount: $${fmt(d.amount)}<br>` +
          `Posted: ${d.posting_date} (${d.days_to_post} days after entry)<br>` +
          `Region: ${d.business_unit} | Account: ${d.account}<br>` +
          `Preparer: ${d.preparer} | Approver: ${d.approver || "(none)"}<br>` +
          `Flags: ${d.flags_fired}`);
      })
      .on("mousemove", event => {
        tooltip.style("left", (event.pageX + 14) + "px").style("top", (event.pageY - 10) + "px");
      })
      .on("mouseout", () => tooltip.style("opacity", 0));

  d3.select("#count").text(`  (n=${data.length})`);
  refreshHighlight();
}

// 3. Filter dropdown - slice the population and re-render.
function applyFilter(val) {
  if (val === "all") return rows;
  const [kind, arg] = val.split(":");
  if (kind === "bu") return rows.filter(r => r.business_unit === arg);
  if (kind === "type") return rows.filter(r => r.entry_type === arg);
  if (kind === "flag") return rows.filter(r => r.flag_count >= +arg);
  return rows;
}
d3.select("#filter").on("change", function () { render(applyFilter(this.value)); });

// 4. Legend (risk levels) - click a band to highlight those points.
const legend = d3.select("#legend");
[["0", "0 flags"], ["1", "1 flag"], ["2", "2 flags"], ["3", "3 flags"]].forEach(([k, label]) => {
  legend.append("span")
    .attr("class", "legend-item")
    .attr("data-level", k)
    .style("cursor", "pointer")
    .html(`<span class="swatch" style="background:${color(+k)}"></span>${label}`)
    .on("click", () => { isolated = (isolated === +k) ? null : +k; refreshHighlight(); });
});
legend.append("span").html("&nbsp; &#9670; manual &nbsp; &#9679; automated");
legend.append("span").style("color", "#888").html("&nbsp; (click a flag level to highlight)");

render(rows);
